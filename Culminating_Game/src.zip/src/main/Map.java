package main;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

import absFrame.Room;

public class Map {

    private BufferedImage mapImage;

    public Room room1;
    public Room hallway1;
    public Room room2;

    public Room currentRoom;

    public Map() {

        loadMap();

        createRooms();

        currentRoom = room1;
    }

    private void loadMap() {

        try {

            URL url =
                getClass().getResource("/testMap.png");

            mapImage = ImageIO.read(url);

        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    private void createRooms() {

        // x, y, width, height
        room1 =
            new Room(0, 0, 800, 600);

        hallway1 =
            new Room(800, 0, 300, 600);

        room2 =
            new Room(1100, 0, 800, 600);

        // Linked list
        room1.next = hallway1;

        hallway1.previous = room1;
        hallway1.next = room2;

        room2.previous = hallway1;

        // Door rectangles
        room1.nextDoor =
            new java.awt.Rectangle(
                750, 250,
                50, 100);

        hallway1.previousDoor =
            new java.awt.Rectangle(
                0, 250,
                50, 100);

        hallway1.nextDoor =
            new java.awt.Rectangle(
                250, 250,
                50, 100);

        room2.previousDoor =
            new java.awt.Rectangle(
                0, 250,
                50, 100);
    }

    public BufferedImage getCurrentRoomImage() {

        return mapImage.getSubimage(
            currentRoom.getMapX(),
            currentRoom.getMapY(),
            currentRoom.getMapWidth(),
            currentRoom.getMapHeight()
        );
    }
}
	
	/**
	 * read img
	 * @param filename - name of the file
	 * @return an BufferedImg object
	 */
    BufferedImage loadImage(String filename) {
        URL url = this.getClass().getResource("/" + filename);
        BufferedImage img = null;

        if (url != null) {
            try {
                img = ImageIO.read(url);
            } catch (IOException e) {
                System.out.println(e.toString());
                JOptionPane.showMessageDialog(null, "An image failed to load: " + filename,
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            System.out.println("URL is null for: " + filename);
        }

        return img;
    }
    
    /**
     * Change the background of the img
     * @param frameChange - contain 2 elements, the direction of change in x and y 
     * 					  - 1 is down and right, -1 is up and left
     * @return true if back background change, false if not
     */
    public boolean changeBackground(int[] frameChange) {
    	int oldSx1 = sx1;
        int oldSy1 = sy1;

        sx1 += screenW * frameChange[0];
        sy1 += screenH * frameChange[1];

        // keep camera inside map image
        if (sx1 < 0) sx1 = 0;
        if (sy1 < 0) sy1 = 0;

        if (sx1 > maxW - screenW) sx1 = maxW - screenW;
        if (sy1 > maxL - screenH) sy1 = maxL - screenH;

        sx2 = sx1 + screenW;
        sy2 = sy1 + screenH;

        // return true only if the camera actually moved
        return sx1/100 != oldSx1/100 || sy1/100 != oldSy1/100; // the division is just to account for the bad shape of the test map
    	
    	

	}
    
    
    
	
}
