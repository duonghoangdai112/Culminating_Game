package absFrame;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class Monster extends Rectangle {
    
    double health, damage, visionRange;    
    double cooldown; 
    
    double dx,dy;
    double xx,yy;
    ArrayList<Projectile> projectiles; 
    int startTime; 

    // Enemy image / animation.
    private BufferedImage monsterImage;
    private BufferedImage[] walkFrames;
    private int walkFrameIndex = 0;
    private int walkFrameCounter = 0;
    private int walkFrameDelay = 8;
    private boolean faceLeft = true;
    
    // initialize all attribute here 
    public Monster(HashMap<String,Integer> stats,int startTime,int x, int y,int width,int height,double speed){
        super(x,y,width,height);
        
        this.health = stats.get("health");
        this.damage = stats.get("damage");
        this.visionRange = stats.get("visionRange");
        
        this.dx = stats.get("speedX")*speed;
        this.dy = stats.get("speedY")*speed;

        this.xx = x;
        this.yy=y;
        
        this.x = x;
        this.y = y;

        this.startTime = startTime;
    }
    
    public void setWorldPosition(int x, int y) {
        this.x = x;
        this.y = y;
        this.xx = x;
        this.yy = y;
    }

    /**
     * Sets the still image used by this monster.
     * This is used as the fallback image if no animation sheet is loaded.
     */
    public void setMonsterImage(BufferedImage img) {
        monsterImage = img;
        if (img != null && width <= 0 && height <= 0) {
            width = img.getWidth();
            height = img.getHeight();
        }
    }

    /**
     * Gives the monster a walking sprite sheet with equal-width frames.
     * This works the same way as the player's walking animation.
     */
    public void setWalkAnimation(BufferedImage sheet, int frameCount) {
        if (sheet == null || frameCount <= 0) {
            return;
        }

        int frameW = sheet.getWidth() / frameCount;
        int frameH = sheet.getHeight();
        if (frameW <= 0 || frameH <= 0) {
            return;
        }

        walkFrames = new BufferedImage[frameCount];
        for (int i = 0; i < frameCount; i++) {
            walkFrames[i] = sheet.getSubimage(i * frameW, 0, frameW, frameH);
        }

        // Keep enemies about the same size as before, but preserve sprite aspect ratio.
        double scale = 100.0 / frameW;
        width = (int) Math.round(frameW * scale);
        height = (int) Math.round(frameH * scale);

        if (monsterImage == null) {
            monsterImage = walkFrames[0];
        }
    }

    private void updateWalkAnimation(boolean moving) {
        if (walkFrames == null || walkFrames.length == 0) {
            walkFrameIndex = 0;
            walkFrameCounter = 0;
            return;
        }

        if (!moving) {
            walkFrameIndex = 0;
            walkFrameCounter = 0;
            return;
        }

        walkFrameCounter++;
        if (walkFrameCounter >= walkFrameDelay) {
            walkFrameCounter = 0;
            walkFrameIndex = (walkFrameIndex + 1) % walkFrames.length;
        }
    }

    public BufferedImage getCurrentImage() {
        if (walkFrames != null && walkFrames.length > 0) {
            return walkFrames[walkFrameIndex];
        }
        return monsterImage;
    }

    /**
     * Draws the monster as an image instead of just drawing its rectangle hitbox.
     */
    public void drawMonster(Graphics2D g2) {
        BufferedImage img = getCurrentImage();
        if (img == null) {
            g2.draw(this);
            return;
        }

        if (faceLeft) {
            g2.drawImage(img, x, y, width, height, null);
        } else {
            // Flip horizontally when the monster is facing right.
            g2.drawImage(img, x + width, y, -width, height, null);
        }
    }

    public double getHealth() {
        return health;
    }

    public void reduceHealth(double damage){
        health -= damage; 
    }
    
    public abstract void Attack() ;
    //when create a bullet just get the monster speedX and Y and times it by cons for the speed
    
    
    /**
     * Turn and move the monster toward the character 
     * @param charX character X position
     * @param charY character Y position
     */
    public void move(int charX, int charY) {
        int oldX = x;
        int oldY = y;
        
        double deltX =  charX-x; 
        double deltY =  charY-y; 

        if (deltX < 0) {
            faceLeft = true;
        } else if (deltX > 0) {
            faceLeft = false;
        }

        double xCorrect =1;
        double yCorrect = 1; 
        
        double speedX = 0;
        double speedY = 0;
        
        // check x
        if(deltX>0) { speedX =dx ;}
        else if (deltX<0) {speedX = -dx;}
        else {yCorrect = 2; }
        
        // check y
        if(deltY>0) {speedY = dy;}
        else if (deltY<0) {speedY = -dy;}

        else {xCorrect = 2; }
        
        
        // velocity correction 
        xx += (speedX*xCorrect);
        yy += (speedY*yCorrect);
        
        x = (int) xx;
        y=(int) yy;

        updateWalkAnimation(x != oldX || y != oldY);
                
    } 
    /**
     * update bullet position and call the monster to attack if ready
     * @param time the time from the game clock
     */
    public void checkCD(int time ) {
        // if (time-startTime) % cooldown == 0 => this.attack()
        // for each projectile => p.move() 
    }
    
    /**
     * Check if monster projectile hit block or character and do action accordingly
     * @param charX - character X position
     * @param charY - character Y position 
     * @param Rtiles - collection of room tiles
     * @return
     */
    public void checkCollision (int charX, int charY, ArrayList<Tiles> Rtiles, Character c) {
        double monDamage = 0;
        if(charX == x && charY == y) {
            int collisionDamage = 5;
            monDamage += (double) collisionDamage;
        }

        c.health-= (int) monDamage;
    }
}
